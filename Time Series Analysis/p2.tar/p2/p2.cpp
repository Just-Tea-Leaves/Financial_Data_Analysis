#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#include <string>
#include <fstream>
using namespace std;

struct node {
	char key[16];
	char val[16];
};


int findNodeKey(node* mmap, int elements, string key)
{
	for (int i = 0; i < elements; i++)
	{
		if (strcmp(mmap[i].key, key.c_str()) == 0)
		{
			return i;
		}
	}
	return -1;
}

int getCommand(string st)
{
	if (st == "isrt")
		return 0;
	else if (st == "delt")
		return 1;
	else if (st == "prtt")
		return 2;
	else if (st == "prtk")
		return 3;
	else if (st == "prta")
		return 4;
	else if (st == "blnk")
		return 5;
	return -1;
}

int main(int argc, char* argv[])
{
	if (argc == 2 && (strcmp(argv[1],"-hw")==0))
	{
		
		exit(0);
	}
	else if (argc == 3)
	{

		int mmap_size = atoi(argv[1]);
		string filename = argv[2];

		//int mmap_size = atoi("10");
		//string filename = "T2.txt";

		node* myMap = 0;
		myMap = new node[mmap_size];
		int m_ent = 0;

		for (int i = 0; i < mmap_size; i++)
		{
			strcpy(myMap[i].key, "");
			strcpy(myMap[i].val, "");
		}

		ifstream file(filename, ios::in);
		string input = "";

		if (file)
		{
			int command = 0;
			string key = "";
			string val = "";
			int firstspace = 0;
			int index = 0;

			while (getline(file, input)) 
			{
				if (input[0] != '#' && input[0] != '\0') 
				{
					command = getCommand(input.substr(0, 4));

					switch (command)
					{
					case 0://done
						input = input.substr(5);
						firstspace = input.find(" ");
						key = input.substr(0, firstspace);
						val = input.substr(firstspace + 1);
						if (m_ent + 1 == mmap_size)
						{
							cout << "OUT OF SPACE FOR " << key << " " << val << "\n";
							exit(-1);
						}
						else if ((index = findNodeKey(myMap, m_ent, key)) != -1)
						{
							strcpy(myMap[index].val, val.c_str());
						}
						else
						{
							strcpy(myMap[m_ent].key, key.c_str());
							strcpy(myMap[m_ent].val, val.c_str());
							m_ent++;
						}

						break;
					case 1://done
						input = input.substr(5);
						firstspace = input.find(" ");
						key = input.substr(0, firstspace);
						if ((index = findNodeKey(myMap, m_ent, key)) != -1)
						{
							strcpy(myMap[index].key, "");
						}
						else
						{
							cout << "Key not found\n";
						}
						break;
					case 2://done
						input = input.substr(5);
						cout << input << "\n";
						break;
					case 3:
						input = input.substr(5);
						firstspace = input.find(" ");
						key = input.substr(0, firstspace);
						if ((index = findNodeKey(myMap, m_ent, key)) != -1)
						{
							cout << myMap[index].key << " " << myMap[index].val << "\n";
						}
						else
						{
							cout << "KEY DOES NOT EXIST "<< key <<"\n";
						}
						break;
					case 4:
						for (int i = 0; i < m_ent; i++)
						{
							if (strcmp(myMap[i].key,"") != 0)
							{
								cout << myMap[i].key << " " << myMap[i].val << "\n";
							}
						}
						break;
					case 5://done
						cout << '\n';
						break;
					default:
						break;
					}
				}
			}

			file.close();
		}

		if (myMap != 0)
		{
			delete[] myMap;
			myMap = 0;
		}
		
	}

return 0;

}
